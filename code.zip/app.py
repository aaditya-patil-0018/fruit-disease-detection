from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from detection import detect
import requests
import os
import json

# changes needed here
UPLOAD_FOLDER = 'static/uploads/'

app = Flask(__name__)
app.secret_key = "secretkeysomething"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

def save_file(file):
    # file = request.files["file"]
    filename = secure_filename(file.filename)
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
    return True

@app.route("/", methods=["GET", "POST"])
def index():
    fruit_disease_descriptions = {
            "APPLE_blotch": "A disease affecting apple trees characterized by dark, irregular blotches on the fruit's surface.",
            "APPLE_normal": "Healthy state of apple trees without any significant diseases or abnormalities.",
            "APPLE_rot": "A condition in apple fruits where decay or decomposition sets in, often caused by fungal or bacterial infection.",
            "APPLE_scab": "A common apple tree disease caused by a fungus, resulting in scaly or scabby lesions on leaves and fruit.",
            "GUAVA_pytopthora": "A disease affecting guava plants caused by the Pytophthora pathogen, leading to wilting and root rot.",
            "GUAVA_root": "A condition in guava plants characterized by issues in the root system, potentially leading to stunted growth or other symptoms.",
            "GUAVA_scab": "A fungal disease affecting guava trees, causing scaly or scabby lesions on leaves and fruit similar to apple scab.",
            "LEMON_canker": "A bacterial infection affecting lemon trees, resulting in raised lesions on leaves, fruit, and stems.",
            "LEMON_healthy": "Healthy state of lemon trees without any significant diseases or abnormalities.",
            "LEMON_mold": "A condition in lemon fruits where mold growth occurs, often due to environmental factors or improper storage.",
            "LEMON_scab": "A fungal disease affecting lemon trees, causing scaly or scabby lesions on leaves and fruit similar to apple and guava scab."
        }

    if request.method == "GET":
        return render_template("index.html", fruit_name="", fruit_disease="", disease_description="", fruit_image="")
    elif request.method == "POST":
        fileUpload = save_file(request.files["file"])

        # posting the picture and getting the fruit_disease and detection
        # response = requests.post("http://127.0.0.1:5000/model", files={"file": open(UPLOAD_FOLDER+request.files["file"].filename, "rb")})
        # response = response.json()
        detection = detect("static/uploads/"+request.files['file'].filename)
        response = {"disease": detection, "description":fruit_disease_descriptions[detection]}
        fruit_name = response["disease"].split('_')[0]
        fruit_disease = response["disease"]
        disease_description = response["description"]
        return render_template("index.html", fruit_name=fruit_name, fruit_disease=fruit_disease, disease_description=disease_description, fruit_image=request.files["file"].filename)

if __name__ == "__main__":
    app.run(debug=True, port=8080)